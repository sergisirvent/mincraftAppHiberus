class Item {
    String name;
    String namespacedId;
    String description;
    String image;
    int stackSize;
    bool renewable;

    Item({
        required this.name,
        required this.namespacedId,
        required this.description,
        required this.image,
        required this.stackSize,
        required this.renewable,
    });
}