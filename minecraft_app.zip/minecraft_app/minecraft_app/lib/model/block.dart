class Block {
    String name;
    String namespacedId;
    String description;
    String image;
    String? tool;

    Block({
        required this.name,
        required this.namespacedId,
        required this.description,
        required this.image,
        required this.tool,
    });
}
