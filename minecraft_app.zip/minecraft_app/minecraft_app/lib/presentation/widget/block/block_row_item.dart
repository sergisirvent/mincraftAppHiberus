import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:minecraft_app/presentation/navigation/navigation_routes.dart';

class BlockRowItem extends StatelessWidget {
  const BlockRowItem({super.key, required this.image, required this.name});

  final String image;
  final String name;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: (){
        router.go(NavigationRoutes.BLOCK_DETAIL_ROUTE, extra: name);
      },
      child: Card (
        color: Colors.black.withOpacity(0.5),
        child: Center(
          child: CachedNetworkImage(
            imageUrl: image,
          ),
        ),
      )
    );
  }
}