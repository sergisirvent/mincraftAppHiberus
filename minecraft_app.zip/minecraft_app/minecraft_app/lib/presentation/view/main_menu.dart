import 'package:flutter/material.dart';
import 'package:minecraft_app/presentation/navigation/navigation_routes.dart';

class MainMenu extends StatefulWidget {
  const MainMenu({super.key});

  @override
  State<MainMenu> createState() => _MainMenuState();
}

class _MainMenuState extends State<MainMenu> {
  
  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            "assets/dirt.jpg",
            repeat: ImageRepeat.repeat,
          ),
          Center(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Spacer(),
                Image.asset("assets/appLogo.png"),
                const Spacer(),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: FractionallySizedBox(
                    widthFactor: 0.8,
                    child: ElevatedButton(
                      onPressed: () {
                        router.go(NavigationRoutes.BLOCK_LIST_ROUTE);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white
                      ), 
                      child: const Padding(
                        padding:  EdgeInsets.all(16.0),
                        child:  Text("Blocks",style: TextStyle(fontSize: 25),),
                      )),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: FractionallySizedBox(
                    widthFactor: 0.8,
                    child: ElevatedButton(
                      onPressed: () {
                        router.go(NavigationRoutes.ITEM_LIST_ROUTE);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white
                      ), 
                      child: const Padding(
                        padding:  EdgeInsets.all(16.0),
                        child:  Text("Items",style: TextStyle(fontSize: 25),),
                      )),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: FractionallySizedBox(
                    widthFactor: 0.8,
                    child: ElevatedButton(
                      onPressed: () {
                        router.go(NavigationRoutes.BLOCK_GAME_ROUTE);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green,
                        foregroundColor: Colors.white
                      ), 
                      child: const Padding(
                        padding:  EdgeInsets.all(16.0),
                        child:  Text("Blocks Game",style: TextStyle(fontSize: 25),),
                      )),
                  ),
                ),
                  const Spacer(),
              ],
            ),
          )
        ],
      ),
    );
  }
}