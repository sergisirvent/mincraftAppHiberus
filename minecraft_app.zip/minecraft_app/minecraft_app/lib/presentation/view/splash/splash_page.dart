import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:minecraft_app/presentation/navigation/navigation_routes.dart';
import 'package:lottie/lottie.dart';

class SplashPage extends StatefulWidget {
  const SplashPage({super.key});

  @override
  State<SplashPage> createState() => _SplashPageState();
}

class _SplashPageState extends State<SplashPage> {

  @override
  void initState() {
    super.initState();
    _navigateToNextPage();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Lottie.asset('assets/lottie_splash_screen.json',
        repeat: true,
        animate: true,
        width: 120,
      ),
      ),
    );
  }
  
  _navigateToNextPage() async {
    await Future.delayed(const Duration(seconds: 2));

    if(mounted){//si el widget esta mntado, es una variable interna
      context.go(NavigationRoutes.MENU_ROUTE);
    }
  }

  
}