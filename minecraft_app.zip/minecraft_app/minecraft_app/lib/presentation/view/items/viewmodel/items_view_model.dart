import 'dart:async';

import 'package:minecraft_app/domain/items_repository.dart';
import 'package:minecraft_app/model/item.dart';
import 'package:minecraft_app/presentation/base/base_view_model.dart';
import 'package:minecraft_app/presentation/model/resource_state.dart';

class ItemsViewModel extends BaseViewModel {
  final ItemsRepository _itemsRepository;

  final StreamController<ResourceState<List<Item>>> getItemsListState = StreamController();
  final StreamController<ResourceState<Item>> getItemByNameState = StreamController();
  
  ItemsViewModel({required ItemsRepository itemsRepository}) : _itemsRepository = itemsRepository;

  fetchItemsList() {
    getItemsListState.add(ResourceState.loading());

    _itemsRepository
      .getItemsList()
      .then(
        (value) => getItemsListState.add(ResourceState.success(value)))
      .catchError(
        (error) => getItemsListState.add(ResourceState.error(error)));
  }

  fetchItemByName(String name){
    getItemByNameState.add(ResourceState.loading());
    _itemsRepository
      .getItemByName(name)
      .then(
        (value) => getItemByNameState.add(ResourceState.success(value)))
      .catchError(
        (error) => getItemByNameState.add(ResourceState.error(error)));
  }

  @override
  void dispose() {
    getItemByNameState.close();
    getItemsListState.close();
  }

}