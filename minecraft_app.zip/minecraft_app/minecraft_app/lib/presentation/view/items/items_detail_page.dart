import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:minecraft_app/di/app_modules.dart';
import 'package:minecraft_app/model/item.dart';
import 'package:minecraft_app/presentation/model/resource_state.dart';
import 'package:minecraft_app/presentation/navigation/navigation_routes.dart';
import 'package:minecraft_app/presentation/view/items/viewmodel/items_view_model.dart';
import 'package:minecraft_app/presentation/widget/error/error_view.dart';
import 'package:minecraft_app/presentation/widget/loading/loading_view.dart';

class ItemsDetailPage extends StatefulWidget {
  const ItemsDetailPage({super.key, required this.itemName});

  final String itemName;

  @override
  State<ItemsDetailPage> createState() => _ItemsDetailPageState();
}

class _ItemsDetailPageState extends State<ItemsDetailPage> {

  final ItemsViewModel _itemsViewModel = inject<ItemsViewModel>();
  Item? _item;
  String renewableController = "No";

  @override
  void initState() {
    super.initState();

    _itemsViewModel.getItemByNameState.stream.listen((state) {
      switch(state.status){
        
        case Status.LOADING:
          LoadingView.show(context);
          break;
        case Status.SUCCESS:
          LoadingView.hide();
          setState(() {
            _item = state.data!;
            if(_item?.renewable != null && _item!.renewable){
              renewableController = "Yes";
            }
          });
          break;
        case Status.ERROR:
          LoadingView.hide();
          ErrorView.show(context, state.exception.toString(), (){
            _itemsViewModel.fetchItemByName(widget.itemName);
          });
          break;
      }
    });

    _itemsViewModel.fetchItemByName(widget.itemName);
    
    setState(() {});
  }

  @override
  void dispose() {
    super.dispose();
    _itemsViewModel.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: (){
            router.go(NavigationRoutes.ITEM_LIST_ROUTE);
          },
          icon: const Icon(Icons.arrow_back),
        ),
        title: Text(_item?.name ?? "Undefined"),
        backgroundColor: Colors.green,
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            "assets/dirt.jpg",
            repeat: ImageRepeat.repeat,
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Card(
                color: Colors.black.withOpacity(0.5),
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          CachedNetworkImage(
                            imageUrl: _item?.image ?? "https://images.freeimages.com/fic/images/icons/2796/metro_uinvert_dock/256/minecraft.png",
                          ),
                          Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                const Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                                  child: Icon(Icons.font_download, color: Colors.white, size: 30),
                                ),
                                Expanded(child: Text("Name: ${_item?.name ?? "Undefined"}",style: const TextStyle(fontSize: 20,color: Colors.white))),
                              ],
                          ),
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const Padding(
                                  padding:  EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                                  child: Icon(Icons.description, color: Colors.white, size: 30),
                                ),
                                Expanded(child: Text("Description: ${_item?.description ?? "Undefined"}",style: const TextStyle(fontSize: 20,color: Colors.white))),
                              ],
                            ),
                          Row(
                              children: [
                                const Padding(
                                  padding: EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                                  child: Icon(Icons.card_membership, color: Colors.white, size: 30),
                                ),
                                Expanded(child: Text("Id: ${_item?.namespacedId ?? "Undefined"}",style: const TextStyle(fontSize: 20,color: Colors.white))),
                              ],
                            ),
                          Row(
                              children: [
                                const Padding(
                                  padding:  EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                                  child:  Icon(Icons.view_agenda, color: Colors.white, size: 30),
                                ),
                                Text("Stack size: ${_item?.stackSize ?? "Undefined"}",style: const TextStyle(fontSize: 20,color: Colors.white)),
                              ],
                          ),
                          Row(
                            children: [
                              const Padding(
                                padding:  EdgeInsets.symmetric(horizontal: 8, vertical: 16),
                                child:  Icon(Icons.recycling, color: Colors.white, size: 30),
                              ),
                              Text("Renewable: $renewableController",style: const TextStyle(fontSize: 20,color: Colors.white)),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          )
        ],

      ),
    );
  }
}