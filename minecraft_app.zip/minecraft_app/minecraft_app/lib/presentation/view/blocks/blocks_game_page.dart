import 'dart:math';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:minecraft_app/data/remote/network_constants.dart';
import 'package:minecraft_app/di/app_modules.dart';
import 'package:minecraft_app/model/block.dart';
import 'package:minecraft_app/presentation/model/resource_state.dart';
import 'package:minecraft_app/presentation/navigation/navigation_routes.dart';
import 'package:minecraft_app/presentation/view/blocks/viewmodel/blocks_view_model.dart';
import 'package:minecraft_app/presentation/widget/error/error_view.dart';
import 'package:minecraft_app/presentation/widget/loading/loading_view.dart';
import 'package:shared_preferences/shared_preferences.dart';

class BlockGamePage extends StatefulWidget {
  const BlockGamePage({super.key});

  @override
  State<BlockGamePage> createState() => _BlockGamePageState();
}

class _BlockGamePageState extends State<BlockGamePage> {

  final String sharedPreferencesScoreKey = "block_game_score";
  
  int _score = 0;
  int _bestScore = 0;

  final BlocksViewModel _blocksViewModel = inject<BlocksViewModel>();
  List<Block> _blocksList = [];
  Block? _selectedBlock;
  String _guessResult = "Click on the tool";

  @override
  void initState(){
    super.initState();
    setInitialScoreFromPrefs();
    
    _blocksViewModel.getBlocksListState.stream.listen((state) {
      
      
      switch (state.status) {
        case Status.LOADING:
          LoadingView.show(context);
          break;
        case Status.SUCCESS:
          LoadingView.hide();
          setState(() {
            _blocksList = state.data!;
          });
          int rIndex = Random().nextInt(_blocksList.length);
          _selectedBlock = _blocksList[rIndex];
          break;
        case Status.ERROR:
          LoadingView.hide();
          ErrorView.show(context, state.exception!.toString(), () {
            _blocksViewModel.fetchBlocksList();
          });
          break;
          
      }

      
      

    });
    _blocksViewModel.fetchBlocksList();

    
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: const Padding(
          padding:  EdgeInsets.all(20.0),
          child:  Text("Block game"),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            router.go(NavigationRoutes.MENU_ROUTE);
          },
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            "assets/dirt.jpg",
            repeat: ImageRepeat.repeat,
          ),
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    color: Colors.white.withOpacity(0.5),
                    child: const Padding(
                      padding:  EdgeInsets.all(8.0),
                      child:  Text(
                        "Choose the correct tool to pick up this block",
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 25,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                  Card(
                    color: Colors.black.withOpacity(0.5),
                    child: Column(
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Text(_selectedBlock?.name ?? "", style: const TextStyle(color: Colors.white, fontSize: 20),),
                        ),
                        CachedNetworkImage(
                          imageUrl: _selectedBlock?.image ?? "https://images.freeimages.com/fic/images/icons/2796/metro_uinvert_dock/256/minecraft.png",
                        ),
                      ],
                    ),
                  ),
                  Container(
                    color: Colors.white.withOpacity(0.5),
                    child: Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: Text(_guessResult, style: const TextStyle(fontSize: 25)),
                    ),
                  ),
                  Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Card(
                              child:Container(
                                padding: const EdgeInsets.all(24),
                                child: GestureDetector(
                                  onTap: () {
                                    checkCardPressed("Axe");
                                  },
                                  child: Image.asset(
                                    "assets/Axe.png",
                                    width: 50,
                                    ),
                                ),
                              )
                            ),
                            Card(
                              child:Container(
                                padding: EdgeInsets.all(24),
                                child: GestureDetector(
                                  onTap: () {
                                    checkCardPressed("Pickaxe");
                                  },
                                  child: Image.asset(
                                    "assets/Pickaxe.png",
                                    width: 50,
                                    ),
                                ),
                              )
                            ),
                            Card(
                              child:Container(
                                padding: EdgeInsets.all(24),
                                child: GestureDetector(
                                  onTap: () {
                                    checkCardPressed("Hoe");
                                  },
                                  child: Image.asset(
                                    "assets/Hoe.png",
                                    width: 40,
                                    ),
                                ),
                              )
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Card(
                                child:Container(
                                  padding: EdgeInsets.all(24),
                                  child: GestureDetector(
                                    onTap: () {
                                      checkCardPressed("Sword");
                                    },
                                    child: Image.asset(
                                      "assets/Sword.png",
                                      width: 50,
                                      ),
                                  ),
                                )
                              ),
                            Card(
                                child:Container(
                                  padding: EdgeInsets.all(24),
                                  child: GestureDetector(
                                    onTap: () {
                                      checkCardPressed("Shovel");
                                    },
                                    child: Image.asset(
                                      "assets/Shovel.png",
                                      width: 50,
                                      ),
                                  ),
                                )
                              ),
                            Card(
                                child:Container(
                                  padding: EdgeInsets.all(24),
                                  child: GestureDetector(
                                    onTap: () {
                                      checkCardPressed("Shear");
                                    },
                                    child: Image.asset(
                                      "assets/Shear.png",
                                      width: 45,
                                      ),
                                  ),
                                )
                              ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Card(
                              child:Container(
                                padding: EdgeInsets.all(16),
                                child: GestureDetector(
                                  onTap: () {
                                    checkCardPressed("NA");
                                  },
                                  child: Text("No tool asigned")
                                ),
                              )
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Container(
                          color: Colors.white.withOpacity(0.5),
                          child: Padding(
                            padding: EdgeInsets.all(16.0),
                            child: Column(
                              children: [
                                Text("Score: $_score", style: TextStyle(fontSize: 20),textAlign: TextAlign.start),
                                Text("Best: $_bestScore", style: TextStyle(fontSize: 20),textAlign: TextAlign.start),
                              ],
                            ),
                          ),
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
  
  @override
  void dispose() {
    _blocksViewModel.dispose();
    super.dispose();
  }

  int getRandomIndex(){
    return Random().nextInt(_blocksList.length);
  }
  checkCardPressed(String cardString){
    if(_selectedBlock?.tool == null){
      if(cardString == NetworkConstants.NOT_ASSIGNED_TOOL_WORD){
        _score++;
        _selectedBlock = _blocksList[getRandomIndex()];
        _guessResult = "Correct";
      }else{
        if(_score > _bestScore){
          _bestScore = _score;
        }
        _score = 0;
        _guessResult = "Incorrect";
      }
    }else{
      if(cardString == _selectedBlock!.tool){
        _score++;
        _selectedBlock = _blocksList[getRandomIndex()];
        _guessResult = "Correct";
      }else{
        if(_score > _bestScore){
          _bestScore = _score;
        }
        _score = 0;
        _guessResult = "Incorrect";
      }
    }
    setHiScoreInPrefs(_bestScore);
    setState(() {});
  }
  
  setInitialScoreFromPrefs() async {
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    if(_prefs.getInt(sharedPreferencesScoreKey) != null){
      _bestScore = _prefs.getInt(sharedPreferencesScoreKey)!;
    }
  }

  setHiScoreInPrefs(int score) async {
    SharedPreferences _prefs = await SharedPreferences.getInstance();
    _prefs.setInt(sharedPreferencesScoreKey, score);
  }
  
}