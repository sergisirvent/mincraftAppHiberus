import 'dart:async';

import 'package:minecraft_app/domain/blocks_repository.dart';
import 'package:minecraft_app/model/block.dart';
import 'package:minecraft_app/presentation/base/base_view_model.dart';
import 'package:minecraft_app/presentation/model/resource_state.dart';

class BlocksViewModel extends BaseViewModel {
  final BlocksRepository _blocksRepository;

  final StreamController<ResourceState<List<Block>>> getBlocksListState = StreamController();
  final StreamController<ResourceState<Block>> getBlockByNameState = StreamController();
  
  BlocksViewModel({required BlocksRepository blocksRepository}) : _blocksRepository = blocksRepository;

  fetchBlocksList() {
    getBlocksListState.add(ResourceState.loading());

    _blocksRepository
      .getBlocksList()
      .then(
        (value) => getBlocksListState.add(ResourceState.success(value)))
      .catchError(
        (error) => getBlocksListState.add(ResourceState.error(error)));
  }

  fetchBlockByName(String name){
    getBlockByNameState.add(ResourceState.loading());
    _blocksRepository
      .getBlockByName(name)
      .then(
        (value) => getBlockByNameState.add(ResourceState.success(value)))
      .catchError(
        (error) => getBlockByNameState.add(ResourceState.error(error)));
  }

  @override
  void dispose() {
    getBlockByNameState.close();
    getBlocksListState.close();
  }

}