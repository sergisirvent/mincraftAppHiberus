import 'package:flutter/material.dart';
import 'package:minecraft_app/di/app_modules.dart';
import 'package:minecraft_app/model/block.dart';
import 'package:minecraft_app/presentation/model/resource_state.dart';
import 'package:minecraft_app/presentation/navigation/navigation_routes.dart';
import 'package:minecraft_app/presentation/view/blocks/viewmodel/blocks_view_model.dart';
import 'package:minecraft_app/presentation/widget/block/block_row_item.dart';
import 'package:minecraft_app/presentation/widget/error/error_view.dart';
import 'package:minecraft_app/presentation/widget/loading/loading_view.dart';

class BlockListPage extends StatefulWidget {
  const BlockListPage({super.key});

  @override
  State<BlockListPage> createState() => _BlockListPageState();
}

class _BlockListPageState extends State<BlockListPage> {
  final BlocksViewModel _blocksViewModel = inject<BlocksViewModel>();
  List<Block> _blocksList = [];

  @override
  void initState() {
    super.initState();
    
    _blocksViewModel.getBlocksListState.stream.listen((state) {
      
      
      switch (state.status) {
        case Status.LOADING:
          LoadingView.show(context);
          break;
        case Status.SUCCESS:
          LoadingView.hide();
          setState(() {
            _blocksList = state.data!;
          });
          break;
        case Status.ERROR:
          LoadingView.hide();
          ErrorView.show(context, state.exception!.toString(), () {
            _blocksViewModel.fetchBlocksList();
          });
          break;
          
      }

      
      

    });
    _blocksViewModel.fetchBlocksList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.green,
        title: const Padding(
          padding:  EdgeInsets.all(20.0),
          child:  Text("Blocks"),
        ),
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {
            router.go(NavigationRoutes.MENU_ROUTE);
          },
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            "assets/dirt.jpg",
            repeat: ImageRepeat.repeat,
          ),
          SafeArea(
            child: GridView.builder(
              itemCount: _blocksList.length,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8
              ),
              itemBuilder: (_,index){
                final block = _blocksList[index];
                //construimos el item
                return BlockRowItem(image: block.image, name: block.namespacedId);
              },

            ),
          )
        ],
      ),
    );
  }
  @override
  void dispose() {
    _blocksViewModel.dispose();
    super.dispose();
  }
}