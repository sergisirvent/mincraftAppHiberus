import 'package:go_router/go_router.dart';
import 'package:minecraft_app/presentation/view/blocks/blocks_detail_page.dart';
import 'package:minecraft_app/presentation/view/blocks/blocks_game_page.dart';
import 'package:minecraft_app/presentation/view/blocks/blocks_list_page.dart';
import 'package:minecraft_app/presentation/view/items/items_detail_page.dart';
import 'package:minecraft_app/presentation/view/items/items_list_page.dart';
import 'package:minecraft_app/presentation/view/main_menu.dart';
import 'package:minecraft_app/presentation/view/splash/splash_page.dart';

class NavigationRoutes {

  //routes
  static const String INITIAL_ROUTE = "/";
  static const String MENU_ROUTE = "/menu";
  static const String BLOCK_LIST_ROUTE = "/block-list";
  static const String BLOCK_DETAIL_ROUTE = "$BLOCK_LIST_ROUTE/$_BLOCK_DETAIL_PATH";
  static const String ITEM_LIST_ROUTE = "/item-list";
  static const String ITEM_DETAIL_ROUTE = "$ITEM_LIST_ROUTE/$_ITEM_DETAIL_PATH";
  static const String BLOCK_GAME_ROUTE = "/block-game";


  //paths
  static const String _BLOCK_DETAIL_PATH = "block-detail";
  static const String _ITEM_DETAIL_PATH = "item-detail";
}

final GoRouter router = GoRouter(
  initialLocation: NavigationRoutes.INITIAL_ROUTE,
  routes: [
    GoRoute(
      path: NavigationRoutes.INITIAL_ROUTE,
      builder: (context,state) => const SplashPage()
    ),
    
    GoRoute(
      path: NavigationRoutes.MENU_ROUTE,
      builder: (context,state) => const MainMenu(),
    ),
    GoRoute(
      path: NavigationRoutes.BLOCK_LIST_ROUTE,
      builder: (context,state) => const BlockListPage(),
      routes: [
        GoRoute(
          path: NavigationRoutes._BLOCK_DETAIL_PATH,
          builder: (context,state) => BlockDetailPage(
            blockName: state.extra as String,
          ),
        )
      ]
    ),
    GoRoute(
      path: NavigationRoutes.ITEM_LIST_ROUTE,
      builder: (context,state) => const ItemsListPage(),
      routes: [
        GoRoute(
          path: NavigationRoutes._ITEM_DETAIL_PATH,
          builder: (context,state) => ItemsDetailPage(
            itemName: state.extra as String,
          ),
        )
      ]
    ),
    GoRoute(
      path: NavigationRoutes.BLOCK_GAME_ROUTE,
      builder: (context,state) => const BlockGamePage(),
    ),
  ]
);