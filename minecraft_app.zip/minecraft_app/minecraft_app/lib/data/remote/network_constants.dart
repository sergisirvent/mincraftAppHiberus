class NetworkConstants {
  static const BASE_URL = "https://minecraft-api.vercel.app/api";

  static const BLOCKS_PATH = "$BASE_URL/blocks";
  static const ITEMS_PATH = "$BASE_URL/items";

  static const AXE_TOOL_WORD = "Axe";
  static const PICKAXE_TOOL_WORD = "Pickaxe";
  static const SWORD_TOOL_WORD = "Sword";
  static const SHOVEL_TOOL_WORD = "Shovel";
  static const SHEAR_TOOL_WORD = "Shears";
  static const HOE_TOOL_WORD = "Hoe";
  static const NOT_ASSIGNED_TOOL_WORD = "NA";

}
