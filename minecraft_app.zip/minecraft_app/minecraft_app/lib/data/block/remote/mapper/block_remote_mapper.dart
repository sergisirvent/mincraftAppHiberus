
import 'package:minecraft_app/data/block/remote/model/block_remote_model.dart';
import 'package:minecraft_app/model/block.dart';

class BlockRemoteMapper {
  static Block fromRemote(BlockRemoteModel remoteModel) {
    return Block(
      name: remoteModel.name,
      namespacedId: remoteModel.namespacedId,
      description: remoteModel.description, 
      image: remoteModel.image, 
      tool: remoteModel.tool);
  }
}