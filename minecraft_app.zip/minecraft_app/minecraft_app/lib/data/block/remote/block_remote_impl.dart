import 'package:minecraft_app/data/block/remote/model/block_remote_model.dart';
import 'package:minecraft_app/data/remote/error/remote_error_mapper.dart';
import 'package:minecraft_app/data/remote/network_client.dart';
import 'package:minecraft_app/data/remote/network_constants.dart';

class BlockRemoteImpl {
  final NetworkClient _networkClient;

  BlockRemoteImpl({required NetworkClient networkClient}) : _networkClient = networkClient;
  
  Future<List<BlockRemoteModel>> getBlocks() async {
    try {
      final response = await _networkClient.dio.get(NetworkConstants.BLOCKS_PATH);

      final listResponse = response.data as List<dynamic>;
      return listResponse.map((e) => BlockRemoteModel.fromMap(e)).toList();
    }catch(e){
      throw RemoteErrorMapper.getException(e);
    }
  }

  Future<BlockRemoteModel> getBlockByName(String name) async {
    try {
      final response = await _networkClient.dio.get(
        NetworkConstants.BLOCKS_PATH,
        queryParameters: {"namespacedId":name}
      );
      final listResponse = response.data as List<dynamic>;
      final itemsList = listResponse.map((e) => BlockRemoteModel.fromMap(e)).toList();
      return itemsList[0];
      
    }catch(e){
      throw RemoteErrorMapper.getException(e);
    }
  }
  
}