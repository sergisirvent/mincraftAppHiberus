class BlockRemoteModel {
    String name;
    String namespacedId;
    String description;
    String image;
    String? tool;

    BlockRemoteModel({
        required this.name,
        required this.namespacedId,
        required this.description,
        required this.image,
        required this.tool,
    });

    factory BlockRemoteModel.fromMap(Map<String, dynamic> json) => BlockRemoteModel(
        name: json["name"],
        namespacedId: json["namespacedId"],
        description: json["description"],
        image: json["image"],
        tool: json["tool"],
    );

    Map<String, dynamic> toMap() => {
        "name": name,
        "namespacedId": namespacedId,
        "description": description,
        "image": image,
        "tool": tool,
    };
    
}