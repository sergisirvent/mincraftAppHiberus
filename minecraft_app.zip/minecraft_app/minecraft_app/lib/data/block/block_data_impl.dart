import 'package:minecraft_app/data/block/remote/block_remote_impl.dart';
import 'package:minecraft_app/data/block/remote/mapper/block_remote_mapper.dart';
import 'package:minecraft_app/domain/blocks_repository.dart';
import 'package:minecraft_app/model/block.dart';

class BlockDataImpl extends BlocksRepository {

  final BlockRemoteImpl _remoteImpl;

  BlockDataImpl({required BlockRemoteImpl remoteImpl}) : _remoteImpl = remoteImpl;

  @override
  Future<List<Block>> getBlocksList() async {
    final remoteBlockList = await _remoteImpl.getBlocks();
    return remoteBlockList.map((e) => BlockRemoteMapper.fromRemote(e)).toList();
  }

  @override
  Future<Block> getBlockByName(String name) async {
    final remoteBlock =  await _remoteImpl.getBlockByName(name);

    return BlockRemoteMapper.fromRemote(remoteBlock);
  }
  
}