import 'package:minecraft_app/data/item/remote/item_remote_impl.dart';
import 'package:minecraft_app/data/item/remote/mapper/item_remote_mapper.dart';
import 'package:minecraft_app/domain/items_repository.dart';
import 'package:minecraft_app/model/item.dart';

class ItemDataImpl extends ItemsRepository {

  final ItemRemoteImpl _remoteImpl;
  ItemDataImpl({required ItemRemoteImpl remoteImpl}) : _remoteImpl = remoteImpl;
  
  @override
  Future<List<Item>> getItemsList() async {
    final remoteItemsList = await _remoteImpl.getItems();
    return remoteItemsList.map((e) => ItemRemoteMapper.fromRemote(e)).toList();
  }

  @override
  Future<Item> getItemByName(String name) async {
    final remoteItem = await _remoteImpl.getItemByName(name);
    return ItemRemoteMapper.fromRemote(remoteItem);
  }
}