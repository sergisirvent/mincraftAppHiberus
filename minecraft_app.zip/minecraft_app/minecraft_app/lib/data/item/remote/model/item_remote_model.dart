class ItemRemotemodel {
    String name;
    String namespacedId;
    String description;
    String image;
    int stackSize;
    bool renewable;

    ItemRemotemodel({
        required this.name,
        required this.namespacedId,
        required this.description,
        required this.image,
        required this.stackSize,
        required this.renewable,
    });

    factory ItemRemotemodel.fromMap(Map<String, dynamic> json) => ItemRemotemodel(
        name: json["name"],
        namespacedId: json["namespacedId"],
        description: json["description"],
        image: json["image"],
        stackSize: json["stackSize"],
        renewable: json["renewable"],
    );

    Map<String, dynamic> toMap() => {
        "name": name,
        "namespacedId": namespacedId,
        "description": description,
        "image": image,
        "stackSize": stackSize,
        "renewable": renewable,
    };
}