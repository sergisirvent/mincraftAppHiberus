import 'package:minecraft_app/data/item/remote/model/item_remote_model.dart';
import 'package:minecraft_app/data/remote/error/remote_error_mapper.dart';
import 'package:minecraft_app/data/remote/network_client.dart';
import 'package:minecraft_app/data/remote/network_constants.dart';

class ItemRemoteImpl {
  final NetworkClient _networkClient;

  ItemRemoteImpl({required NetworkClient networkClient}) : _networkClient = networkClient;
  
  Future<List<ItemRemotemodel>> getItems() async {
    try {
      final response = await _networkClient.dio.get(NetworkConstants.ITEMS_PATH);

      final listResponse = response.data as List<dynamic>;
      return listResponse.map((e) => ItemRemotemodel.fromMap(e)).toList();
    }catch(e){
      throw RemoteErrorMapper.getException(e);
    }
  }

  Future<ItemRemotemodel> getItemByName(String name) async {
    try {
      final response = await _networkClient.dio.get(
        NetworkConstants.ITEMS_PATH,
        queryParameters: {"namespacedId":name}
      );
      final listResponse = response.data as List<dynamic>;
      final itemsList = listResponse.map((e) => ItemRemotemodel.fromMap(e)).toList();
      return itemsList[0];
      
    }catch(e){
      throw RemoteErrorMapper.getException(e);
    }
  }
  
}
