import 'package:minecraft_app/data/item/remote/model/item_remote_model.dart';
import 'package:minecraft_app/model/item.dart';

class ItemRemoteMapper {
  static Item fromRemote(ItemRemotemodel remoteModel) {
    return Item(
      name: remoteModel.name,
      namespacedId: remoteModel.namespacedId,
      description: remoteModel.description,
      image: remoteModel.image, 
      stackSize: remoteModel.stackSize, 
      renewable: remoteModel.renewable);
  }
}