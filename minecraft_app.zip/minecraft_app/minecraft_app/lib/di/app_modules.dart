import 'package:get_it/get_it.dart';
import 'package:minecraft_app/data/block/block_data_impl.dart';
import 'package:minecraft_app/data/block/remote/block_remote_impl.dart';
import 'package:minecraft_app/data/item/item_data_impl.dart';
import 'package:minecraft_app/data/item/remote/item_remote_impl.dart';
import 'package:minecraft_app/data/remote/network_client.dart';
import 'package:minecraft_app/domain/blocks_repository.dart';
import 'package:minecraft_app/domain/items_repository.dart';
import 'package:minecraft_app/presentation/view/blocks/viewmodel/blocks_view_model.dart';
import 'package:minecraft_app/presentation/view/items/viewmodel/items_view_model.dart';

final inject = GetIt.instance;

class AppModules {
  setup() {
    _setupMainModule();
    _setupBlockModule();
    _setupItemModule();
  }

  _setupMainModule() {
    inject.registerSingleton(NetworkClient());
  }

  _setupBlockModule() {
    
    inject.registerFactory(() => BlockRemoteImpl(networkClient: inject.get()));
    inject.registerFactory<BlocksRepository>(
        () => BlockDataImpl(remoteImpl: inject.get()));
    inject.registerFactory(() => BlocksViewModel(blocksRepository: inject.get()));
    
    
  }
  
  _setupItemModule() {
    inject.registerFactory(() => ItemRemoteImpl(networkClient: inject.get()));
    inject.registerFactory<ItemsRepository>(
        () => ItemDataImpl(remoteImpl: inject.get()));
    inject.registerFactory(() => ItemsViewModel(itemsRepository: inject.get()));
  }
}