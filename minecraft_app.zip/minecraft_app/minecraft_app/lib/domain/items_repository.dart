import 'package:minecraft_app/model/item.dart';

abstract class ItemsRepository {
  Future<List<Item>> getItemsList();
  Future<Item> getItemByName(String name);
}