import 'package:minecraft_app/model/block.dart';

abstract class BlocksRepository {
  Future<List<Block>> getBlocksList();
  Future<Block> getBlockByName(String name);
}